@extends('layouts.app')

@section('content')
<div class="content-wrap">
    <div class="main">
        <div class="container-fluid">
            
            <!-- /# row -->
            <section id="main-content">
                <div class="row">
                    <div class="col-md-12">
                        <div class="bootstrap-data-table-panel">
                            <div class="row">
                                @foreach ($product_data as $product)
                                    <div class="col-md-3 shadow-lg product mb-2" >
                                        <h4 class="text-center">{{ $product->name }}</h4>
                                        <img class="text-center" src="{{ asset('images/'.$product->image) }}" style="text-align: center;margin-left: 25%;" width="90px" height="90px">
                                        <br>
                                        <br>
                                        <h6 style="margin-left: 25%;">Price : &dollar; {{ $product->price}}</h6>
                                    </div>
                                @endforeach
                            </div>
                            <div class="row">
                                <div class="col-md-4"></div>
                                <div class="col-md-4" align="center">
                                    <?php echo $product_data->render(); ?>
                                </div>
                                <div class="col-md-4"></div>
                        </div>
                        <!-- /# card -->
                    </div>
                    <!-- /# column -->
                </div>
            </section>
        </div>
    </div>
</div>
@endsection
