<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use App\Models\Product;

class ProductController extends Controller
{
    public static function index()
    {
    	$data=Product::product_list();
    	
    	return view('welcome')->with('product_data', $data);
    }
}
