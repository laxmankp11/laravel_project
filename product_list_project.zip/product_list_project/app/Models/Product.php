<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Product extends Model
{
    use HasFactory;
    protected $table = 'product';

    protected $dates = ['deleted_at'];
    protected $fillable = ['name', 'image', 'price'];

    public static function product_list()
    {
    	$data=Product::select('name', 'image', 'price')->orderBy('id', 'DESC')->simplePaginate(10);
    	return $data;
    }
}
