<!-- jquery vendor -->
    <script src=" <?php echo e(asset('asset/js/lib/jquery.min.js')); ?>"></script>
    <script src=" <?php echo e(asset('asset/js/lib/jquery.nanoscroller.min.js')); ?>"></script>
    <!-- nano scroller -->
    <script src=" <?php echo e(asset('asset/js/lib/menubar/sidebar.js')); ?>"></script>
    <script src=" <?php echo e(asset('asset/js/lib/preloader/pace.min.js')); ?>"></script>
    <!-- sidebar -->

    <script src=" <?php echo e(asset('asset/js/lib/bootstrap.min.js')); ?>"></script>
    <script src=" <?php echo e(asset('asset/js/scripts.js')); ?>"></script>
    <!-- bootstrap -->

    <script src=" <?php echo e(asset('asset/js/lib/calendar-2/moment.latest.min.js')); ?>"></script>
    <!-- <script src=" <?php echo e(asset('asset/js/lib/calendar-2/pignose.calendar.min.js')); ?>"></script>
    <script src=" <?php echo e(asset('asset/js/lib/calendar-2/pignose.init.js')); ?>"></script> -->


    <script src=" <?php echo e(asset('asset/js/lib/weather/jquery.simpleWeather.min.js')); ?>"></script>
    <script src=" <?php echo e(asset('asset/js/lib/weather/weather-init.js')); ?>"></script>
    <script src=" <?php echo e(asset('asset/js/lib/circle-progress/circle-progress.min.js')); ?>"></script>
    <script src=" <?php echo e(asset('asset/js/lib/circle-progress/circle-progress-init.js')); ?>"></script>
    <!-- <script src=" <?php echo e(asset('asset/js/lib/chartist/chartist.min.js')); ?>"></script> -->
    <!-- <script src=" <?php echo e(asset('asset/js/lib/sparklinechart/jquery.sparkline.min.js')); ?>"></script> -->
    <!-- <script src=" <?php echo e(asset('asset/js/lib/sparklinechart/sparkline.init.js')); ?>"></script> -->
    <script src=" <?php echo e(asset('asset/js/lib/owl-carousel/owl.carousel.min.js')); ?>"></script>
    <script src=" <?php echo e(asset('asset/js/lib/owl-carousel/owl.carousel-init.js')); ?>"></script>
    <!-- scripit init-->
    <!-- <script src=" <?php echo e(asset('asset/js/dashboard2.js')); ?>"></script> -->

    <!-- scripit init-->
    <script src="<?php echo e(asset('asset/js/lib/data-table/datatables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('asset/js/lib/data-table/dataTables.buttons.min.js')); ?>"></script>
    <script src="<?php echo e(asset('asset/js/lib/data-table/buttons.flash.min.js')); ?>"></script>
    <script src="<?php echo e(asset('asset/js/lib/data-table/jszip.min.js')); ?>"></script>
    <script src="<?php echo e(asset('asset/js/lib/data-table/pdfmake.min.js')); ?>"></script>
    <script src="<?php echo e(asset('asset/js/lib/data-table/vfs_fonts.js')); ?>"></script>
    <script src="<?php echo e(asset('asset/js/lib/data-table/buttons.html5.min.js')); ?>"></script>
    <script src="<?php echo e(asset('asset/js/lib/data-table/buttons.print.min.js')); ?>"></script>
    <script src="<?php echo e(asset('asset/js/lib/data-table/datatables-init.js')); ?>"></script><?php /**PATH /var/www/html/product_list_project/resources/views/layouts/footer.blade.php ENDPATH**/ ?>