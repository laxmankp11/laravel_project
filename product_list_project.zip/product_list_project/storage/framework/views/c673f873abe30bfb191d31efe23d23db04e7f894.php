<?php $__env->startSection('content'); ?>
<div class="content-wrap">
    <div class="main">
        <div class="container-fluid">
            
            <!-- /# row -->
            <section id="main-content">
                <div class="row">
                    <div class="col-md-12">
                        <div class="bootstrap-data-table-panel">
                            <div class="row">
                                <?php $__currentLoopData = $product_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-md-3 shadow-lg product mb-2" >
                                        <h4 class="text-center"><?php echo e($product->name); ?></h4>
                                        <img class="text-center" src="<?php echo e(asset('images/'.$product->image)); ?>" style="text-align: center;margin-left: 25%;" width="90px" height="90px">
                                        <br>
                                        <br>
                                        <h6 style="margin-left: 25%;">Price : &dollar; <?php echo e($product->price); ?></h6>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <div class="row">
                                <div class="col-md-4"></div>
                                <div class="col-md-4" align="center">
                                    <?php echo $product_data->render(); ?>
                                </div>
                                <div class="col-md-4"></div>
                        </div>
                        <!-- /# card -->
                    </div>
                    <!-- /# column -->
                </div>
            </section>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/product_list_project/resources/views/welcome.blade.php ENDPATH**/ ?>